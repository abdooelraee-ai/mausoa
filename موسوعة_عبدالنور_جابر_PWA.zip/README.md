# موسوعة عبدالنور جابر — PWA

الملفات:
- index.html: واجهة الموسوعة
- manifest.json: تعريف التطبيق وقابلية التثبيت
- service-worker.js: تشغيل أجزاء التطبيق محليًا بعد أول زيارة
- icon.svg: أيقونة التطبيق

## النشر
ارفع الملفات الأربعة إلى مستودع GitHub، ثم فعّل GitHub Pages.
بعد فتح رابط Pages عبر HTTPS:
- Android/Chrome: اختر تثبيت التطبيق / Add to Home screen.
- Windows/Chrome أو Edge: اختر Install.
- iPhone/iPad: مشاركة ← إضافة إلى الشاشة الرئيسية.

ملاحظة: البحث في Google والمصادر الخارجية يحتاج اتصالًا بالإنترنت.
